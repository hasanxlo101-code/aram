import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Globe,
  Search,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Server,
  Lock,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { VirusTotalAnalysis } from '../../types';
import { analyzeVirusTotalUrl } from '../../utils/advancedSecurityEngine';

export const VirusTotalUrlScanner: React.FC = () => {
  const [urlInput, setUrlInput] = useState('https://kaya-safesec.hasanxlo.workers.dev');
  const [analysis, setAnalysis] = useState<VirusTotalAnalysis>(() =>
    analyzeVirusTotalUrl('https://kaya-safesec.hasanxlo.workers.dev')
  );
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeTab, setActiveTab] = useState<'detection' | 'details' | 'community'>('detection');
  const [vendorFilter, setVendorFilter] = useState<'all' | 'malicious' | 'clean'>('all');

  const handleScan = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!urlInput.trim()) return;

    setIsAnalyzing(true);
    setTimeout(() => {
      setAnalysis(analyzeVirusTotalUrl(urlInput.trim()));
      setIsAnalyzing(false);
    }, 450);
  };

  const setPresetUrl = (target: string) => {
    setUrlInput(target);
    setIsAnalyzing(true);
    setTimeout(() => {
      setAnalysis(analyzeVirusTotalUrl(target));
      setIsAnalyzing(false);
    }, 350);
  };

  const isMalicious = analysis.detectionStats.malicious > 0;
  const isSuspicious = analysis.detectionStats.suspicious > 0;

  const filteredVendors = analysis.vendors.filter((v) => {
    if (vendorFilter === 'malicious') return v.category === 'malicious' || v.category === 'suspicious';
    if (vendorFilter === 'clean') return v.category === 'clean';
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="p-5 sm:p-6 rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900/90 via-slate-900/40 to-slate-950 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
              <Radio className="h-4 w-4 animate-pulse" />
              <span>VIRUSTOTAL-GRADE MULTI-ENGINE RADAR</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white">
              فاحص الروابط والعناوين والتصيد الاحتيالي (72+ محرك أمني)
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl leading-relaxed">
              تحليل فوري ومكثف للروابط وصفحات الويب عبر محاكاة كبرى محركات مكافحة التهديدات السيبرانية (Google Safe Browsing, Kaspersky, Bitdefender, Cloudflare Radar, Cisco Talos, Fortinet).
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-xl self-start sm:self-auto">
            <CheckCircle2 className="h-4 w-4" />
            <span>72 محركاً نشطاً</span>
          </div>
        </div>

        {/* Input Bar */}
        <form onSubmit={handleScan} className="flex flex-col sm:flex-row gap-2 pt-2">
          <div className="relative flex-1">
            <Globe className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="أدخل رابط الموقع، الدومين، أو عنوان الـ URL لفحصه... (مثال: https://example.com)"
              className="w-full rounded-xl border border-slate-700 bg-slate-950 pr-10 pl-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-colors font-mono"
              dir="ltr"
            />
          </div>

          <button
            type="submit"
            disabled={isAnalyzing}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm transition-all shadow-lg shadow-cyan-500/15 cursor-pointer disabled:opacity-50"
          >
            <Search className="h-4 w-4" />
            <span>{isAnalyzing ? 'جارٍ الفحص عبر 72 محركاً...' : 'فحص الرابط الآن'}</span>
          </button>
        </form>

        {/* Preset Sample Targets */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-500 font-mono">نماذج للتجربة:</span>
          <button
            type="button"
            onClick={() => setPresetUrl('https://kaya-safesec.hasanxlo.workers.dev')}
            className="px-2.5 py-1 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-slate-300 font-mono transition-colors cursor-pointer text-[11px]"
          >
            KAyA SafeSec (رسمي)
          </button>
          <button
            type="button"
            onClick={() => setPresetUrl('http://login-verify-account-security-update.xyz/bank/auth')}
            className="px-2.5 py-1 rounded-lg border border-rose-500/30 bg-rose-950/20 hover:bg-rose-900/30 text-rose-300 font-mono transition-colors cursor-pointer text-[11px]"
          >
            نموذج تصيد احتيالي (Phishing Demo)
          </button>
          <button
            type="button"
            onClick={() => setPresetUrl('https://free-crypto-giveaway-claim-reward.top/wallet')}
            className="px-2.5 py-1 rounded-lg border border-amber-500/30 bg-amber-950/20 hover:bg-amber-900/30 text-amber-300 font-mono transition-colors cursor-pointer text-[11px]"
          >
            نموذج احتيال عملات رقمية
          </button>
        </div>
      </div>

      {/* Detection Score Gauge Card */}
      <div className={`p-6 rounded-2xl border transition-all ${
        isMalicious
          ? 'border-rose-500/50 bg-gradient-to-b from-rose-950/30 via-slate-950 to-slate-950 shadow-xl shadow-rose-500/5'
          : isSuspicious
          ? 'border-amber-500/50 bg-gradient-to-b from-amber-950/30 via-slate-950 to-slate-950 shadow-xl shadow-amber-500/5'
          : 'border-emerald-500/40 bg-gradient-to-b from-emerald-950/20 via-slate-950 to-slate-950 shadow-xl shadow-emerald-500/5'
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            {/* Score Ring */}
            <div className={`relative flex h-24 w-24 shrink-0 items-center justify-center rounded-2xl border-2 font-mono font-extrabold ${
              isMalicious
                ? 'border-rose-500 bg-rose-950/50 text-rose-400 text-2xl'
                : isSuspicious
                ? 'border-amber-500 bg-amber-950/50 text-amber-400 text-2xl'
                : 'border-emerald-500 bg-emerald-950/50 text-emerald-400 text-2xl'
            }`}>
              <div className="text-center">
                <span className="block">{analysis.detectionStats.malicious}</span>
                <span className="text-[11px] text-slate-400 font-normal">/ {analysis.detectionStats.total}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold font-mono ${
                  isMalicious
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : isSuspicious
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {isMalicious ? 'موقع خبيث ومصيدة تصيد مؤكدة' : isSuspicious ? 'موقع مشبوه ومحفوف بالمخاطر' : 'موقع آمن ونظيف تماماً'}
                </span>
                <span className="text-xs font-mono text-slate-500">HTTP {analysis.httpResponse}</span>
              </div>

              <h3 className="text-lg font-bold text-white break-all font-mono" dir="ltr">
                {analysis.targetUrl}
              </h3>
              <p className="text-xs text-slate-300">{analysis.reputationText}</p>
            </div>
          </div>

          {/* Quick Stats Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="p-3 rounded-xl border border-rose-500/20 bg-rose-950/20">
              <span className="text-[10px] text-slate-400 block">محركات كشفت تهديداً</span>
              <span className="text-lg font-extrabold text-rose-400">{analysis.detectionStats.malicious}</span>
            </div>
            <div className="p-3 rounded-xl border border-amber-500/20 bg-amber-950/20">
              <span className="text-[10px] text-slate-400 block">اشتباه بالروابط</span>
              <span className="text-lg font-extrabold text-amber-400">{analysis.detectionStats.suspicious}</span>
            </div>
            <div className="p-3 rounded-xl border border-emerald-500/20 bg-emerald-950/20">
              <span className="text-[10px] text-slate-400 block">محركات صنفته سليماً</span>
              <span className="text-lg font-extrabold text-emerald-400">{analysis.detectionStats.clean}</span>
            </div>
            <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60">
              <span className="text-[10px] text-slate-400 block">تقييم المجتمع</span>
              <span className="text-lg font-extrabold text-cyan-400">{analysis.communityScore}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-slate-800 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('detection')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'detection'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          قائمة المحركات الأمنية ({analysis.vendors.length})
        </button>
        <button
          onClick={() => setActiveTab('details')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'details'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          التفاصيل التقنية والشهادات
        </button>
        <button
          onClick={() => setActiveTab('community')}
          className={`px-4 py-2 rounded-lg transition-colors cursor-pointer ${
            activeTab === 'community'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          تصنيفات الأمان والمجتمع
        </button>
      </div>

      {/* TAB 1: VENDORS GRID */}
      {activeTab === 'detection' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs text-slate-400 font-mono">
              عرض {filteredVendors.length} من أصل {analysis.vendors.length} محركاً
            </span>
            <div className="flex items-center gap-1.5 text-xs font-mono">
              <button
                onClick={() => setVendorFilter('all')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  vendorFilter === 'all' ? 'bg-slate-800 text-white font-bold' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                الكل
              </button>
              <button
                onClick={() => setVendorFilter('malicious')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  vendorFilter === 'malicious' ? 'bg-rose-950 text-rose-300 font-bold' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                التهديدات فقط
              </button>
              <button
                onClick={() => setVendorFilter('clean')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  vendorFilter === 'clean' ? 'bg-emerald-950 text-emerald-300 font-bold' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                السليمة
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredVendors.map((vendor, idx) => {
              const isBad = vendor.category === 'malicious' || vendor.category === 'suspicious';
              return (
                <div
                  key={idx}
                  className={`p-3 rounded-xl border flex items-center justify-between font-mono text-xs ${
                    isBad
                      ? 'border-rose-500/40 bg-rose-950/20 text-rose-300'
                      : 'border-slate-800/80 bg-slate-900/30 text-slate-300'
                  }`}
                >
                  <span className="font-semibold truncate max-w-[170px]">{vendor.name}</span>
                  <span className={`text-[11px] px-2 py-0.5 rounded ${
                    isBad
                      ? 'bg-rose-900/40 text-rose-400 font-bold'
                      : 'text-emerald-400 font-medium'
                  }`}>
                    {isBad ? '⚠ ' + vendor.result : '✓ ' + vendor.result}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: TECHNICAL DETAILS */}
      {activeTab === 'details' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-3">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Server className="h-4 w-4 text-cyan-400" />
              <span>استضافة وحل النطاق (DNS & IP Resolution)</span>
            </h4>
            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">عنوان IP المستهدف:</span>
                <span className="text-emerald-400">{analysis.ipResolution}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">استجابة السيرفر:</span>
                <span>HTTP {analysis.httpResponse} OK</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">الرابط النهائي بعد التوجيه:</span>
                <span className="truncate max-w-[200px]" dir="ltr">{analysis.finalUrl}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-3">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <Lock className="h-4 w-4 text-emerald-400" />
              <span>شهادة التشفير والأمان (SSL/TLS Certificate)</span>
            </h4>
            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">جهة الإصدار:</span>
                <span className="text-cyan-400">{analysis.sslIssuer}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">تاريخ الفحص:</span>
                <span>{analysis.lastAnalysisDate}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                <span className="text-slate-500">فحص الثغرات الحرج:</span>
                <span className={isMalicious ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                  {isMalicious ? 'مكتشف تهديد أمني نشط' : 'لا توجد أنماط شائعة مكشوفة'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: COMMUNITY & CATEGORIES */}
      {activeTab === 'community' && (
        <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/40 space-y-4">
          <h4 className="text-sm font-bold text-white">تصنيفات الأمان الصادرة عن مراكز الرصد العالمية</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
            {Object.entries(analysis.categories).map(([vendor, cat]) => (
              <div key={vendor} className="p-3 rounded-lg border border-slate-800 bg-slate-950/70">
                <span className="text-slate-500 text-[11px] block">{vendor}</span>
                <span className="text-white font-bold block mt-1">{cat}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
