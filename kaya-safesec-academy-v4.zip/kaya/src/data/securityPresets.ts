import { WorkerShieldConfig } from '../types';

export const DEFAULT_WORKER_SHIELD_CONFIG: WorkerShieldConfig = {
  forceHttps: true,
  enableSecurityHeaders: true,
  enableRateLimiting: true,
  rateLimitMaxRequests: 60,
  rateLimitWindowSec: 60,
  blockBadBots: true,
  blockSqlInjection: true,
  blockXssPayloads: true,
  enableGeoBlocking: false,
  blockedCountries: ['RU', 'CN', 'KP'],
  enableIpFiltering: false,
  blockedIps: ['198.51.100.14', '203.0.113.88'],
  customCspDirectives: "default-src 'self'; script-src 'self' 'unsafe-inline'; img-src 'self' data: https:;",
};

export const SAMPLE_BUGGY_WORKER_CODE = `// Typical Buggy Cloudflare Worker Code
export default {
  async fetch(request) {
    const response = await fetch(request);

    // BUG 1: Mutating immutable headers throws TypeError: Can't modify immutable headers
    response.headers.set('X-Frame-Options', 'DENY');
    
    // BUG 2: Missing CORS preflight handling for OPTIONS requests
    // BUG 3: Unhandled errors crash the worker without friendly 500 response
    // BUG 4: Missing HSTS and Content-Security-Policy

    return response;
  }
};`;
