import React, { useState } from 'react';
import { 
  Download, 
  FileText, 
  Search, 
  Check, 
  BookOpen, 
  ExternalLink,
  Shield,
  FileCheck,
  Tag,
  Package,
  FolderArchive,
  FileCode,
  HardDrive,
  Sparkles,
  Terminal,
  Layers
} from 'lucide-react';
import { WordCourse } from '../../types/wordCourses';
import { DOWNLOADABLE_DOCS } from '../../data/downloadableDocsData';

interface DocumentsLibraryProps {
  wordCourses: WordCourse[];
  onOpenWordViewer: (course: WordCourse) => void;
  onOpenPaymentNotice: (course: WordCourse) => void;
}

export const DocumentsLibrary: React.FC<DocumentsLibraryProps> = ({
  wordCourses,
  onOpenWordViewer,
  onOpenPaymentNotice,
}) => {
  const [activeTab, setActiveTab] = useState<'docs' | 'word'>('docs');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [downloadedDocIds, setDownloadedDocIds] = useState<string[]>([]);

  const filteredDocs = DOWNLOADABLE_DOCS.filter((doc) => {
    if (selectedCategory !== 'all' && doc.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = doc.title.toLowerCase().includes(q);
      const matchDesc = doc.description.toLowerCase().includes(q);
      const matchTag = doc.tags.some(t => t.toLowerCase().includes(q));
      return matchTitle || matchDesc || matchTag;
    }
    return true;
  });

  const handleDownloadFile = async (docId: string, title: string, fileUrl: string) => {
    try {
      const res = await fetch(fileUrl);
      if (!res.ok) throw new Error('missing');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileUrl.split('/').pop() || 'kaya-doc.md';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setDownloadedDocIds(prev => [...prev, docId]);
    } catch {
      alert('تعذّر تنزيل الملف حاليًا. حاول لاحقًا.');
    }
  };

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header Banner */}
      <div className="relative rounded-2xl bg-gradient-to-r from-[#0c1633] via-[#091124] to-[#070d1e] border border-cyan-500/20 p-6 sm:p-8 overflow-hidden shadow-xl">
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>المكتبة المركزية للأدلة والوثائق الفنية القابلة للتنزيل</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            مستودع الوثائق الأمنية وكتيبات الطوارئ والمقررات
          </h2>
          <p className="text-slate-300 text-sm leading-relaxed">
            مكتبة متخصصة تضم خطط الاستجابة للطوارئ، بطاقات المرشحات الشبكية لـ Wireshark، قوائم فحص OWASP المعيارية، وملفات الـ 15 مساقاً بصيغة Microsoft Word الرسمية.
          </p>
        </div>

        {/* Tab switch */}
        <div className="relative z-10 mt-6 pt-6 border-t border-slate-800 flex items-center gap-3">
          <button
            onClick={() => setActiveTab('docs')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'docs'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <FileCheck className="w-4 h-4" />
            <span>الأدلة وخطط الاستجابة ({DOWNLOADABLE_DOCS.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('word')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeTab === 'word'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>مقررات Word التفاعلية ({wordCourses.length} مساق)</span>
          </button>
        </div>
      </div>

      {activeTab === 'docs' && (
        <div className="space-y-6">
          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث في الأدلة، الكتيبات، أو الكلمات المفتاحية..."
                className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto text-xs">
              <span className="text-slate-400 ml-1">التصنيف:</span>
              {['all', 'دليل عملي', 'قائمة تحقق', 'ملخص أوامر', 'إطار عمل', 'تقرير نموذج'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    selectedCategory === cat
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat === 'all' ? 'الكل' : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredDocs.map((doc) => {
              const isDownloaded = downloadedDocIds.includes(doc.id);
              return (
                <div
                  key={doc.id}
                  className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-4 group shadow-lg"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-cyan-950/70 border border-cyan-500/30 text-cyan-300">
                        {doc.category}
                      </span>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                        {doc.format}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition line-clamp-2 leading-snug">
                      {doc.title}
                    </h3>

                    <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                      {doc.description}
                    </p>

                    <div className="flex flex-wrap gap-1 pt-1">
                      {doc.tags.map((t, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-850 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">ملف Markdown قابل للتحويل إلى PDF/Word</span>

                    <button
                      onClick={() => handleDownloadFile(doc.id, doc.title, doc.fileUrl)}
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                        isDownloaded
                          ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/10'
                      }`}
                    >
                      {isDownloaded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>تم التنزيل</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" />
                          <span>تنزيل المستند</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'word' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {wordCourses.map((c) => (
            <div
              key={c.id}
              className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-4 shadow-lg"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 font-semibold text-[11px]">
                    {c.levelLabelAr}
                  </span>
                  <span className="text-slate-400 font-mono text-[11px]">
                    {c.docMeta.fileSize} · {c.docMeta.pages} صفحة
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white line-clamp-1">{c.title}</h3>
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{c.subtitle}</p>

                <div className="text-[11px] text-slate-400 bg-slate-950 p-2 rounded-lg border border-slate-850 font-mono truncate" dir="ltr">
                  {c.docMeta.fileName}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-850 flex items-center justify-between">
                <span className="text-xs text-emerald-400 font-bold">
                  {c.isFree ? 'متاح للجميع مجاناً' : 'مشمول بالاشتراك'}
                </span>
                <button
                  onClick={() => {
                    if (c.isFree) {
                      onOpenWordViewer(c);
                    } else {
                      onOpenPaymentNotice(c);
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 text-xs font-semibold transition"
                >
                  <span>استعراض الفصول</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
