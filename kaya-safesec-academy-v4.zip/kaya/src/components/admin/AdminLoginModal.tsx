import React, { useState } from 'react';
import { X, Lock, AlertCircle, Loader2 } from 'lucide-react';
import { signInWithGoogle, isAdminUser, logout, authErrorAr } from '../../lib/firebase';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (email: string) => void;
}

// دخول المشرف عبر حساب Google موثّق. لا توجد كلمات مرور داخل الشيفرة.
export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [errorMsg, setErrorMsg] = useState('');
  const [busy, setBusy] = useState(false);
  if (!isOpen) return null;

  const handle = async () => {
    setBusy(true); setErrorMsg('');
    try {
      const { user } = await signInWithGoogle();
      if (!isAdminUser(user)) {
        await logout();
        setErrorMsg('هذا الحساب غير مخوّل بدخول لوحة الإدارة.');
        return;
      }
      onLoginSuccess(user.email!);
      onClose();
    } catch (e) {
      setErrorMsg(authErrorAr(e));
    } finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" dir="rtl">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-7 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400"><Lock className="h-5 w-5" /></div>
            <div>
              <h3 className="text-base font-bold text-white">دخول إدارة الأكاديمية</h3>
              <span className="text-xs font-mono text-slate-400">KAyA_SafeSec Administrator</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 cursor-pointer"><X className="h-5 w-5" /></button>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">سجّل الدخول بحساب Google المخوّل. يتم التحقق من الصلاحية على الخادم عبر قواعد Firestore، وليس من المتصفح.</p>
        {errorMsg && <div className="flex gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300"><AlertCircle className="h-4 w-4 shrink-0" /><span>{errorMsg}</span></div>}
        <button onClick={handle} disabled={busy} className="w-full rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold py-3 text-sm flex items-center justify-center gap-2 cursor-pointer">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}الدخول عبر Google
        </button>
      </div>
    </div>
  );
};
