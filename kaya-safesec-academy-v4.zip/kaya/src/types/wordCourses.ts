export type CourseLevel = 'beginner' | 'intermediate' | 'expert';

export interface DocSection {
  subtitle: string;
  content: string;
  codeOrBox?: string;
  tip?: string;
}

export interface DocChapter {
  number: string;
  title: string;
  sections: DocSection[];
}

export interface WordCourse {
  id: string;
  title: string;
  subtitle: string;
  level: CourseLevel;
  levelLabelAr: string;
  isFree: boolean;
  priceUsd: number;
  hours: number;
  badge: string;
  docMeta: {
    fileName: string;
    fileSize: string;
    pages: number;
    wordsCount: number;
    lastUpdated: string;
    author: string;
  };
  chapters: DocChapter[];
  prerequisites: string[];
  learningOutcomes: string[];
}

export interface XpBadge {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  isUnlocked: boolean;
  xpRequirement: number;
  category: 'fundamentals' | 'web' | 'forensics' | 'defense' | 'master';
}

export interface EnrolledCourseProgress {
  courseId: string;
  courseTitle: string;
  totalLessons: number;
  completedLessons: number;
  enrolledAt: string;
  lastAccessedAt: string;
  isCompleted: boolean;
  type: 'word' | 'academy';
  category: string;
}

export interface VisitorUser {
  id: string;
  name: string;
  email: string;
  joinedDate: string;
  enrolledCourseIds: string[];
  solvedLabIds?: string[];
  customProgress?: Record<string, number>; // courseId -> completed lessons count
  paidCourseIds?: string[]; // مسارات متوسط/خبير تم فتحها بالدفع أو بكود تفعيل
}

// محتوى حصري لمسار مدفوع (سكربتات/أوامر/مراجع أدوات شرعية معروفة + منهجية المختبر)
// هذا المحتوى تعليمي ومرجعي فقط لأدوات مفتوحة المصدر معروفة تُستخدم باختبار مُصرَّح به داخل بيئة المختبر، وليس أكواد اختراق حصرية أو ضارة.
export interface PremiumContentBlock {
  id: string;
  title: string;
  // أمر/سكربت مرجعي (أدوات علنية معروفة مثل nmap/Wireshark/OWASP ZAP) + شرح الاستخدام الآمن المصرّح به
  referenceCommand?: string;
  explanation: string;
}

export interface PremiumCourseContent {
  courseId: string;
  updatedAt: string;
  labEnvironmentSetup: string; // كيفية تجهيز بيئة المختبر المعزولة (VM/Docker)
  blocks: PremiumContentBlock[];
  downloadableAssets?: { name: string; note: string }[];
}

// كود تفعيل يصدره الأدمن يدويًا لفتح مسار مدفوع قبل تفعيل بوابة الدفع الإلكتروني
export interface ActivationCode {
  code: string;
  courseId: string;
  createdAt: string;
  createdBy: string;
  maxUses: number;
  usedBy: string[]; // uids
  active: boolean;
}

// طلب اهتمام/حجز لمسار مدفوع قبل اكتمال بوابة الدفع (Lead) يراه الأدمن فقط
export interface CourseLead {
  id: string;
  courseId: string;
  courseTitle: string;
  email: string;
  createdAt: string;
  status: 'new' | 'contacted' | 'converted';
}
