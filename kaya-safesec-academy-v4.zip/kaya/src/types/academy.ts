export interface SyllabusItem {
  number: string;
  title: string;
  subtitle: string;
  description?: string;
  duration?: string;
  hasLab?: boolean;
}

export type CourseTier = 'free' | 'premium' | 'expert';

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  category: 'network' | 'offensive' | 'forensics' | 'cert' | 'advanced' | 'ai' | 'lab';
  hours: number;
  lessonsCount: number;
  badge: string;
  difficulty: 'مبتدئ' | 'متوسط' | 'متقدم' | 'احترافي';
  outcomesIntro: string;
  outcomes: string[];
  syllabusIntro: string;
  syllabus: SyllabusItem[];
  prerequisites: string[];
  xpReward: number;
  enrolledStudents: number;
  iconName: string;
  isPopular?: boolean;
  // === نظام المستويات والدفع ===
  tier: CourseTier;              // free | premium (متوسط) | expert (خبير)
  priceUsd?: number;             // السعر بالدولار (فارغ/0 إذا free)
  lockedTeaser?: string;         // نص تشويقي يظهر للزوار غير المشتركين بدل المحتوى الحصري
  hasExclusiveLab?: boolean;     // هل يملك هذا المسار محتوى مختبر حصري (premiumContent/{id})
}

export interface LabChallenge {
  id: string;
  title: string;
  category: string;
  badgeIcon: string;
  difficulty: 'متوسط' | 'متقدم' | 'خبير';
  description: string;
  tags: string[];
  xp: number;
}

export interface CertificateData {
  id: string;
  studentName: string;
  courseTitle: string;
  issueDate: string;
  certificateNumber: string;
  grade: string;
  instructor: string;
}
