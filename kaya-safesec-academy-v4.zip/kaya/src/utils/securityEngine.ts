import { PasswordStrengthResult, WorkerLintResult, WorkerShieldConfig } from '../types';

/**
 * Computes Shannon entropy of a string (higher = more random / obfuscated)
 */
export function calculateShannonEntropy(str: string): number {
  if (!str || str.length === 0) return 0;
  const frequencies: Record<string, number> = {};
  for (const char of str) {
    frequencies[char] = (frequencies[char] || 0) + 1;
  }
  let entropy = 0;
  const len = str.length;
  for (const count of Object.values(frequencies)) {
    const p = count / len;
    entropy -= p * Math.log2(p);
  }
  return Number(entropy.toFixed(2));
}

/**
 * Cloudflare Worker Code Static Analyzer & Auto-Fixer
 * Solves "حلل وقم بالتعديلات وأصلح الأخطاء" for Cloudflare Workers
 */
export function lintWorkerCode(code: string): WorkerLintResult {
  const issues: WorkerLintResult['issues'] = [];

  // 1. Immutable Headers Check
  const immutableHeadersRegex = /response\.headers\.(set|append|delete)\s*\(/;
  if (immutableHeadersRegex.test(code) && !code.includes('new Headers(response.headers)')) {
    issues.push({
      id: 'immutable_headers',
      severity: 'error',
      messageAr: 'خطأ قاتل: محاولة تعديل ترويسات Response مباشرة يسبب TypeError: Can\'t modify immutable headers.',
      messageEn: "Critical Bug: Modifying response.headers directly throws 'TypeError: Can't modify immutable headers'.",
      fixAr: 'استنساخ الترويسات أولاً عبر: const newHeaders = new Headers(response.headers); ثم تمريرها إلى Response جديد.',
      fixEn: 'Clone headers first via: const newHeaders = new Headers(response.headers); then wrap in new Response().',
    });
  }

  // 2. Missing Options Preflight
  if (!code.includes("request.method === 'OPTIONS'") && !code.includes('OPTIONS')) {
    issues.push({
      id: 'missing_cors_options',
      severity: 'warning',
      messageAr: 'تحذير CORS: غياب معالجة طلبات OPTIONS التمهيدية (Preflight) قد يؤدي إلى فشل اتصالات المتصفح عبر النطاقات.',
      messageEn: 'CORS Warning: Missing preflight OPTIONS request handler may cause cross-origin client fetch failures.',
      fixAr: 'إضافة فحص if (request.method === "OPTIONS") وإرجاع ترويسات CORS مع حالة 204 No Content.',
      fixEn: 'Handle OPTIONS preflight by returning 204 No Content with appropriate Access-Control-* headers.',
    });
  }

  // 3. Unhandled Try/Catch
  if (!code.includes('try {') || !code.includes('catch')) {
    issues.push({
      id: 'unhandled_exceptions',
      severity: 'warning',
      messageAr: 'غياب معالج الأخطاء try/catch: أي خطأ في الخادم الأصلي سيتسبب في شاشة خطأ رمادية غير ودية (Error 1101 Worker Threw Exception).',
      messageEn: 'Missing try/catch boundary: Uncaught exceptions will return a generic Cloudflare 1101 Worker Exception.',
      fixAr: 'تغليف الاستدعاء الرئيسي بـ try/catch وإرجاع استجابة JSON أنيقة برمز 500 ورسالة تفصيلية للمطور.',
      fixEn: 'Wrap execution in try/catch block returning a structured JSON error response on failure.',
    });
  }

  // 4. Missing HSTS or CSP
  if (!code.includes('Strict-Transport-Security') || !code.includes('Content-Security-Policy')) {
    issues.push({
      id: 'missing_security_headers',
      severity: 'info',
      messageAr: 'توصية أمنية: ينصح بحقن ترويسات HSTS و CSP لحماية الموقع ضد هجمات XSS و SSL Stripping.',
      messageEn: 'Security Enhancement: Inject HSTS and Content-Security-Policy for defense-in-depth protection.',
      fixAr: 'إضافة ترويسة Strict-Transport-Security وترويسة Content-Security-Policy إلى الاستجابة الصادرة.',
      fixEn: 'Append HSTS and CSP directives into outgoing response headers.',
    });
  }

  // Synthesize Clean Hardened Worker Code
  const cleanCode = `/**
 * ================================================================
 *  KAYA SAFESEC — AUTO-FIXED & HARDENED CLOUDFLARE WORKER
 *  Status: Verified & Fixed (No immutable header bugs)
 *  Deploy Target: https://kaya-safesec.hasanxlo.workers.dev
 * ================================================================
 */

export default {
  async fetch(request, env, ctx) {
    // 1. Handle CORS Preflight (OPTIONS)
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
          'Access-Control-Max-Age': '86400',
        },
      });
    }

    try {
      // 2. Forward request to upstream origin
      const originResponse = await fetch(request);

      // 3. FIX: Clone headers to prevent "Can't modify immutable headers" TypeError
      const secureHeaders = new Headers(originResponse.headers);

      // 4. Inject Hardened Security Headers
      secureHeaders.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
      secureHeaders.set('Content-Security-Policy', "default-src 'self' https: data:; script-src 'self' 'unsafe-inline';");
      secureHeaders.set('X-Frame-Options', 'DENY');
      secureHeaders.set('X-Content-Type-Options', 'nosniff');
      secureHeaders.set('Referrer-Policy', 'strict-origin-when-cross-origin');
      secureHeaders.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
      secureHeaders.set('Server', 'Kaya-SafeSec-Protected');
      secureHeaders.delete('X-Powered-By');

      // Add CORS allowance
      secureHeaders.set('Access-Control-Allow-Origin', '*');

      // 5. Return pristine hardened response
      return new Response(originResponse.body, {
        status: originResponse.status,
        statusText: originResponse.statusText,
        headers: secureHeaders,
      });
    } catch (err) {
      // Graceful error recovery instead of generic Cloudflare 1101 crash
      return new Response(
        JSON.stringify({
          error: 'Internal Worker Exception Intercepted',
          message: err instanceof Error ? err.message : 'Unknown exception',
          guard: 'Kaya SafeSec Edge Shield',
          timestamp: new Date().toISOString(),
        }),
        {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
        }
      );
    }
  },
};`;

  return {
    issues,
    cleanCode,
    hasErrors: issues.some(i => i.severity === 'error'),
  };
}

/**
 * Cloudflare Worker Shield Code Synthesizer
 */
export function generateCloudflareWorkerCode(config: WorkerShieldConfig): string {
  const blockedCountriesArray = JSON.stringify(config.blockedCountries);
  const blockedIpsArray = JSON.stringify(config.blockedIps);

  return `/**
 * ================================================================
 *  KAYA SAFESEC — CLOUDFLARE WORKER SECURITY SHIELD
 *  Author: Hasan (hasan.xlo101@gmail.com)
 *  Target: https://kaya-safesec.hasanxlo.workers.dev
 * ================================================================
 */

const BLOCKED_COUNTRIES = new Set(${blockedCountriesArray});
const BLOCKED_IPS = new Set(${blockedIpsArray});
const RATE_LIMIT_MAP = new Map(); // In-memory edge rate limit cache

// OWASP Top 10 Threat Inspection Patterns
const SQLI_REGEX = /('(''|[^'])*')|(\\b(SELECT|UNION|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|EXEC|BENCHMARK|SLEEP)\\b)/i;
const XSS_REGEX = /<\\s*script|javascript\\s*:|onload\\s*=|onerror\\s*=|eval\\s*\\(|alert\\s*\\(/i;
const BAD_BOT_AGENTS = [
  'sqlmap', 'nikto', 'havij', 'masscan', 'nmap', 'zgrab',
  'python-requests', 'curl/', 'wget/', 'go-http-client'
];

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const clientIp = request.headers.get('CF-Connecting-IP') || '0.0.0.0';
    const country = request.cf?.country || 'XX';
    const userAgent = (request.headers.get('User-Agent') || '').toLowerCase();

    ${config.forceHttps ? `// 1. Force HTTPS Protocol
    if (url.protocol === 'http:') {
      url.protocol = 'https:';
      return Response.redirect(url.toString(), 301);
    }` : '// HTTPS enforcement disabled'}

    ${config.enableGeoBlocking ? `// 2. Geo-Fencing & Country Filtering
    if (BLOCKED_COUNTRIES.has(country)) {
      return new Response(JSON.stringify({
        error: 'Access Denied',
        reason: 'Geo-restriction policy applied by Kaya SafeSec',
        country: country
      }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' }
      });
    }` : '// Geo-blocking disabled'}

    ${config.enableIpFiltering ? `// 3. IP Reputation & Blacklisting
    if (BLOCKED_IPS.has(clientIp)) {
      return new Response('403 Forbidden: IP blacklisted by Kaya SafeSec firewall', { status: 403 });
    }` : '// IP Blacklisting disabled'}

    ${config.blockBadBots ? `// 4. Bad Bot & Malicious Scanner Blocker
    if (BAD_BOT_AGENTS.some(bot => userAgent.includes(bot))) {
      return new Response('403 Forbidden: Automated vulnerability scanner blocked', { status: 403 });
    }` : '// Bad bot blocker disabled'}

    ${config.blockSqlInjection || config.blockXssPayloads ? `// 5. OWASP Attack Sanitizer (URL parameters inspection)
    const rawQuery = decodeURIComponent(url.search);
    ${config.blockSqlInjection ? `if (SQLI_REGEX.test(rawQuery)) {
      return new Response('400 Bad Request: Malicious SQL injection sequence detected', { status: 400 });
    }` : ''}
    ${config.blockXssPayloads ? `if (XSS_REGEX.test(rawQuery)) {
      return new Response('400 Bad Request: Potential XSS payload neutralized', { status: 400 });
    }` : ''}` : '// Request sanitization disabled'}

    ${config.enableRateLimiting ? `// 6. Edge Rate Limiting Protection (${config.rateLimitMaxRequests} req / ${config.rateLimitWindowSec}s)
    const now = Date.now();
    const rateWindowMs = ${config.rateLimitWindowSec} * 1000;
    const clientRecord = RATE_LIMIT_MAP.get(clientIp) || { count: 0, resetTime: now + rateWindowMs };

    if (now > clientRecord.resetTime) {
      clientRecord.count = 1;
      clientRecord.resetTime = now + rateWindowMs;
    } else {
      clientRecord.count += 1;
    }
    RATE_LIMIT_MAP.set(clientIp, clientRecord);

    if (clientRecord.count > ${config.rateLimitMaxRequests}) {
      return new Response(JSON.stringify({
        error: 'Too Many Requests',
        retryAfter: Math.ceil((clientRecord.resetTime - now) / 1000)
      }), {
        status: 429,
        headers: {
          'Content-Type': 'application/json',
          'Retry-After': String(Math.ceil((clientRecord.resetTime - now) / 1000))
        }
      });
    }` : '// Rate limiting disabled'}

    // Forward request to origin upstream
    const originResponse = await fetch(request);

    ${config.enableSecurityHeaders ? `// 7. Harden Injected Security Headers
    const secureHeaders = new Headers(originResponse.headers);
    secureHeaders.set('Content-Security-Policy', "${config.customCspDirectives}");
    secureHeaders.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    secureHeaders.set('X-Frame-Options', 'DENY');
    secureHeaders.set('X-Content-Type-Options', 'nosniff');
    secureHeaders.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    secureHeaders.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    secureHeaders.set('Server', 'Kaya-SafeSec-Shield');
    secureHeaders.delete('X-Powered-By');

    return new Response(originResponse.body, {
      status: originResponse.status,
      statusText: originResponse.statusText,
      headers: secureHeaders
    });` : `return originResponse;`}
  }
};
`;
}

/**
 * Calculates Password Entropy & Cracking Complexity
 */
export function calculatePasswordStrength(password: string): PasswordStrengthResult {
  if (!password) {
    return {
      score: 0,
      entropyBits: 0,
      crackTimeOfflineFast: 'فوري (0 ثانية)',
      crackTimeOnlineSlow: 'فوري (0 ثانية)',
      crackTimeGpuCluster: 'فوري (0 ثانية)',
      feedbackAr: ['الرجاء إدخال كلمة مرور لبدء التحليل الأمني.'],
      feedbackEn: ['Please enter a password to evaluate security entropy.'],
      hasLowercase: false,
      hasUppercase: false,
      hasNumbers: false,
      hasSymbols: false,
      isCommonPassword: false,
      ratingLabelAr: 'فارغة',
      ratingLabelEn: 'Empty',
    };
  }

  const hasLowercase = /[a-z]/.test(password);
  const hasUppercase = /[A-Z]/.test(password);
  const hasNumbers = /[0-9]/.test(password);
  const hasSymbols = /[^a-zA-Z0-9]/.test(password);

  let poolSize = 0;
  if (hasLowercase) poolSize += 26;
  if (hasUppercase) poolSize += 26;
  if (hasNumbers) poolSize += 10;
  if (hasSymbols) poolSize += 33;
  if (poolSize === 0) poolSize = 26;

  const entropyBits = Math.round(password.length * Math.log2(poolSize));

  const feedbackAr: string[] = [];
  const feedbackEn: string[] = [];

  const commonWeak = ['password', '123456', 'admin', 'qwerty', '111111', 'welcome', 'kaya'];
  const isCommonPassword = commonWeak.some(w => password.toLowerCase().includes(w));

  if (isCommonPassword) {
    feedbackAr.push('تحتوي على نمط أو كلمة شائعة جداً يمكن تخمينها بدقائق.');
    feedbackEn.push('Contains a common dictionary word easily compromised by basic wordlists.');
  }

  if (password.length < 12) {
    feedbackAr.push(`طول الكلمة (${password.length} محرف) غير كافٍ، يوصى بـ 14 محرفاً كحد أدنى.`);
    feedbackEn.push(`Length (${password.length} chars) is inadequate. Recommended minimum is 14.`);
  }

  if (!hasSymbols) {
    feedbackAr.push('أضف رموزاً خاصة مثل (!@#$%^&*) لزيادة عمق التشفير.');
    feedbackEn.push('Include special punctuation symbols (!@#$%^&*) to expand the keyspace.');
  }

  if (!hasNumbers) {
    feedbackAr.push('إضافة أرقام عشوائية يعزز تعقيد التخمين.');
    feedbackEn.push('Add randomized numeric characters.');
  }

  let score = 0;
  let ratingLabelAr = 'ضعيفة جداً';
  let ratingLabelEn = 'Very Weak';
  let crackTimeOfflineFast = 'فوري';
  let crackTimeOnlineSlow = 'بضع ثوانٍ';
  let crackTimeGpuCluster = 'لحظي (0.01s)';

  if (entropyBits >= 85 && password.length >= 14 && hasSymbols && hasNumbers) {
    score = 4;
    ratingLabelAr = 'حصينة جداً (عسكرية)';
    ratingLabelEn = 'Military Grade';
    crackTimeOfflineFast = '14,000 عام';
    crackTimeOnlineSlow = 'قرون عديدة';
    crackTimeGpuCluster = '350 عاماً';
  } else if (entropyBits >= 65 && password.length >= 12) {
    score = 3;
    ratingLabelAr = 'قوية وموثوقة';
    ratingLabelEn = 'Strong';
    crackTimeOfflineFast = '3 أعوام';
    crackTimeOnlineSlow = '180 عاماً';
    crackTimeGpuCluster = '24 يوماً';
  } else if (entropyBits >= 45 && password.length >= 8) {
    score = 2;
    ratingLabelAr = 'متوسطة';
    ratingLabelEn = 'Moderate';
    crackTimeOfflineFast = 'ساعتان';
    crackTimeOnlineSlow = '3 أشهر';
    crackTimeGpuCluster = '4 دقائق';
  } else {
    score = 1;
    ratingLabelAr = 'ضعيفة';
    ratingLabelEn = 'Weak';
    crackTimeOfflineFast = 'أقل من ثانية';
    crackTimeOnlineSlow = 'يومان';
    crackTimeGpuCluster = 'أقل من ثانية واحدة';
  }

  if (feedbackAr.length === 0) {
    feedbackAr.push('كلمة المرور ممتازة وتحقق أعلى معايير العشوائية وطول السلسلة.');
    feedbackEn.push('Password meets optimal entropy criteria and cryptographic strength.');
  }

  return {
    score,
    entropyBits,
    crackTimeOfflineFast,
    crackTimeOnlineSlow,
    crackTimeGpuCluster,
    feedbackAr,
    feedbackEn,
    hasLowercase,
    hasUppercase,
    hasNumbers,
    hasSymbols,
    isCommonPassword,
    ratingLabelAr,
    ratingLabelEn,
  };
}

/**
 * Cryptographic Password Generator using window.crypto
 */
export function generateSecurePassword(options: {
  length: number;
  includeUppercase: boolean;
  includeLowercase: boolean;
  includeNumbers: boolean;
  includeSymbols: boolean;
  excludeAmbiguous: boolean;
}): string {
  let lower = 'abcdefghijklmnopqrstuvwxyz';
  let upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let nums = '0123456789';
  let syms = '!@#$%^&*()-_=+[]{}|;:,.<>?';

  if (options.excludeAmbiguous) {
    lower = lower.replace(/[ilo]/g, '');
    upper = upper.replace(/[IO]/g, '');
    nums = nums.replace(/[01]/g, '');
    syms = syms.replace(/[:;|]/g, '');
  }

  let charset = '';
  const guaranteed: string[] = [];

  const getRandomChar = (str: string) => {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return str[array[0] % str.length];
  };

  if (options.includeLowercase && lower.length) {
    charset += lower;
    guaranteed.push(getRandomChar(lower));
  }
  if (options.includeUppercase && upper.length) {
    charset += upper;
    guaranteed.push(getRandomChar(upper));
  }
  if (options.includeNumbers && nums.length) {
    charset += nums;
    guaranteed.push(getRandomChar(nums));
  }
  if (options.includeSymbols && syms.length) {
    charset += syms;
    guaranteed.push(getRandomChar(syms));
  }

  if (!charset) charset = lower;

  const resultChars: string[] = [...guaranteed];
  const remaining = options.length - resultChars.length;

  for (let i = 0; i < remaining; i++) {
    resultChars.push(getRandomChar(charset));
  }

  for (let i = resultChars.length - 1; i > 0; i--) {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    const j = array[0] % (i + 1);
    [resultChars[i], resultChars[j]] = [resultChars[j], resultChars[i]];
  }

  return resultChars.join('');
}

/**
 * High-Entropy Passphrase Generator
 */
export function generateSecurePassphrase(wordCount: number = 4): string {
  const dictionary = [
    'falcon', 'granite', 'shield', 'cipher', 'quantum', 'matrix', 'beacon',
    'vertex', 'aurora', 'obsidian', 'sentinel', 'hazard', 'nebula', 'horizon',
    'bastion', 'vortex', 'cobalt', 'paragon', 'citadel', 'vector', 'cortex',
    'phoenix', 'eclipse', 'glacier', 'phantom', 'monolith', 'apex', 'solaris'
  ];

  const words: string[] = [];
  for (let i = 0; i < wordCount; i++) {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    words.push(dictionary[array[0] % dictionary.length]);
  }

  const numArr = new Uint32Array(1);
  crypto.getRandomValues(numArr);
  const suffix = (numArr[0] % 900) + 100;

  return `${words.join('-')}-${suffix}`;
}

