import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
  signOut,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDocFromServer,
  setDoc,
  getDoc,
  deleteDoc,
  collection,
  getDocs,
  arrayUnion,
  updateDoc,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { VisitorUser, PremiumCourseContent, ActivationCode, CourseLead } from '../types/wordCourses';
import { Course } from '../types/academy';

// Initialize Firebase SDK
const app = initializeApp(firebaseConfig);

// Initialize Firestore using the provisioned firestoreDatabaseId
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Firebase Authentication
export const auth = getAuth(app);

// Operation types for strict Firestore Error diagnostics
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Boot verification of connection to Firestore
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Firebase Firestore connection verified successfully.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline. Checking network configuration.');
    } else {
      console.log('Firebase connection initialized:', (error as Error).message);
    }
    return false;
  }
}

// Auto-run connection check on initial boot
testConnection().catch((err) => console.log('Init check:', err));

// Persist student profile & XP to Firestore
export async function syncUserProfileToFirestore(
  user: VisitorUser,
  xp: number,
  completedCourses: string[] = []
): Promise<void> {
  const path = `users/${user.id}`;
  try {
    const userDocRef = doc(db, 'users', user.id);
    const existing = await getDoc(userDocRef);
    const creating = !existing.exists();
    await setDoc(
      userDocRef,
      {
        ...(creating ? { role: 'student', createdAt: new Date().toISOString() } : {}),
        id: user.id,
        email: user.email,
        displayName: user.name,
        xp: xp,
        level: xp > 1500 ? 'خبير سيبراني' : xp > 500 ? 'متوسط دفاعي' : 'مبتدئ واعد',
        enrolledCourses: user.enrolledCourseIds || [],
        completedCourses: completedCourses,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Fetch student profile from Firestore
export async function fetchUserProfileFromFirestore(userId: string): Promise<any | null> {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      return snap.data();
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

// Record security audit scan to Firestore
export async function logScanToFirestore(
  userId: string,
  scanType: 'url' | 'email_breach' | 'phone_osint' | 'simulator' | 'ip' | 'headers' | 'social',
  target: string,
  verdict: string
): Promise<void> {
  const scanId = `scan_${Date.now()}`;
  const path = `users/${userId}/scans/${scanId}`;
  try {
    const scanRef = doc(db, 'users', userId, 'scans', scanId);
    await setDoc(scanRef, {
      id: scanId,
      userId,
      scanType,
      target,
      verdict,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}


// ===== المصادقة الحقيقية (Firebase Auth) =====
// ملاحظة: التحقق الفعلي من صلاحية المشرف يتم في firestore.rules. هذه القائمة لعرض الواجهة فقط.
export const ADMIN_EMAILS = ['hasanxlo101@gmail.com', 'hasan.xlo101@gmail.com'];
export const isAdminUser = (u: FirebaseUser | null) =>
  !!u && !!u.email && u.emailVerified && ADMIN_EMAILS.includes(u.email.toLowerCase());

export const authErrorAr = (e: any): string => {
  const c = String(e?.code || '');
  if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found')) return 'البريد أو كلمة المرور غير صحيحة.';
  if (c.includes('email-already-in-use')) return 'هذا البريد مسجّل مسبقًا. جرّب تسجيل الدخول.';
  if (c.includes('weak-password')) return 'كلمة المرور ضعيفة (6 محارف على الأقل، يفضّل 12+).';
  if (c.includes('invalid-email')) return 'صيغة البريد غير صحيحة.';
  if (c.includes('popup-closed')) return 'أُغلقت نافذة الدخول قبل الإكمال.';
  if (c.includes('too-many-requests')) return 'محاولات كثيرة. انتظر قليلًا ثم أعد المحاولة.';
  if (c.includes('network')) return 'مشكلة في الاتصال بالشبكة.';
  return 'تعذّر إتمام العملية.';
};

export const signInWithGoogle = () => signInWithPopup(auth, new GoogleAuthProvider());
export const signInEmail = (email: string, password: string) => signInWithEmailAndPassword(auth, email, password);
export async function signUpEmail(name: string, email: string, password: string) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  if (name) await updateProfile(cred.user, { displayName: name });
  sendEmailVerification(cred.user).catch(() => {});
  return cred;
}
export const logout = () => signOut(auth);
export const watchAuth = (cb: (u: FirebaseUser | null) => void) => onAuthStateChanged(auth, cb);

// ===================================================================
// إدارة الدورات (Firestore) — بديل التخزين المحلي، يضمن أن تعديلات
// الأدمن حقيقية ودائمة ومرئية لكل الزوار، وليست محصورة بمتصفح واحد.
// الصلاحية الفعلية محصورة بـ isAdmin() في firestore.rules وليس بالواجهة.
// ===================================================================
export async function fetchCoursesFromFirestore(): Promise<Course[] | null> {
  try {
    const snap = await getDocs(collection(db, 'courses'));
    if (snap.empty) return null;
    return snap.docs.map((d) => d.data() as Course);
  } catch (error) {
    console.warn('fetchCoursesFromFirestore:', error);
    return null; // يسمح للواجهة بالرجوع إلى القائمة الافتراضية المحلية
  }
}

export async function saveCourseToFirestore(course: Course): Promise<void> {
  const path = `courses/${course.id}`;
  try {
    await setDoc(doc(db, 'courses', course.id), course, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteCourseFromFirestore(courseId: string): Promise<void> {
  const path = `courses/${courseId}`;
  try {
    await deleteDoc(doc(db, 'courses', courseId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ===================================================================
// المحتوى الحصري للمختبرات (premiumContent) — وصول كامل دون قيود
// للأدمن عبر isAdmin() بالقواعد؛ الطالب لا يصل إليه إلا إذا وُجد مستند
// users/{uid}/paidAccess/{courseId} يثبت دفعه لهذا المسار بالذات.
// ملاحظة: هذا المحتوى يجب أن يقتصر على أدوات/أوامر مرجعية علنية معروفة
// (nmap, Wireshark, OWASP ZAP...) ومنهجية مختبر معزول مُصرَّح به فقط —
// وليس أكواد اختراق أو استغلال حصرية.
export async function fetchPremiumContent(courseId: string): Promise<PremiumCourseContent | null> {
  try {
    const snap = await getDoc(doc(db, 'premiumContent', courseId));
    return snap.exists() ? (snap.data() as PremiumCourseContent) : null;
  } catch (error) {
    console.warn('fetchPremiumContent:', error);
    return null;
  }
}

export async function savePremiumContent(content: PremiumCourseContent): Promise<void> {
  const path = `premiumContent/${content.courseId}`;
  try {
    await setDoc(doc(db, 'premiumContent', content.courseId), content, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ===================================================================
// بوابة الدفع المؤقتة: أكواد تفعيل يصدرها الأدمن يدويًا (MVP) إلى حين
// ربط بوابة دفع إلكترونية حقيقية (Stripe/PayTabs/HyperPay). الأدمن فقط
// يصدر الأكواد ويمنح/يسحب الوصول المدفوع (مفروض بقواعد Firestore).
export async function issueActivationCode(courseId: string, createdBy: string, maxUses = 1): Promise<ActivationCode> {
  const code = `KAYA-${courseId.slice(0, 6).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  const record: ActivationCode = { code, courseId, createdAt: new Date().toISOString(), createdBy, maxUses, usedBy: [], active: true };
  await setDoc(doc(db, 'activationCodes', code), record);
  return record;
}

export async function redeemActivationCode(code: string, userId: string): Promise<{ ok: boolean; courseId?: string; message: string }> {
  const cleanCode = code.trim().toUpperCase();
  try {
    const ref = doc(db, 'activationCodes', cleanCode);
    const snap = await getDoc(ref);
    if (!snap.exists()) return { ok: false, message: 'كود التفعيل غير صحيح.' };
    const data = snap.data() as ActivationCode;
    if (!data.active) return { ok: false, message: 'هذا الكود غير مُفعَّل.' };
    if (data.usedBy.includes(userId)) return { ok: true, courseId: data.courseId, message: 'لديك وصول مسبق بهذا الكود.' };
    if (data.usedBy.length >= data.maxUses) return { ok: false, message: 'تم استهلاك كل مرات استخدام هذا الكود.' };
    // 1) تسجيل الاستخدام على الكود نفسه (مسموح بقواعد Firestore للمستخدم الموقّع فقط)
    await updateDoc(ref, { usedBy: arrayUnion(userId) });
    // 2) إنشاء مستند الوصول المدفوع الخاص بالطالب لنفس المسار (يتحقق من القواعد أن الكود صالح لهذا المسار بالذات)
    await setDoc(doc(db, 'users', userId, 'paidAccess', data.courseId), {
      courseId: data.courseId,
      viaCode: cleanCode,
      grantedAt: new Date().toISOString(),
    });
    return { ok: true, courseId: data.courseId, message: 'تم فتح المسار المدفوع بنجاح!' };
  } catch (error) {
    console.warn('redeemActivationCode:', error);
    return { ok: false, message: 'تعذّر التحقق من الكود الآن، أو لا تملك صلاحية استخدامه لهذا المسار.' };
  }
}

// منح وصول مدفوع مباشرة من الأدمن (بعد تأكيد تحويل بنكي/تواصل يدوي، بدون كود)
export async function grantPaidAccess(userId: string, courseId: string, adminEmail: string): Promise<void> {
  const path = `users/${userId}/paidAccess/${courseId}`;
  try {
    await setDoc(doc(db, 'users', userId, 'paidAccess', courseId), {
      courseId,
      viaCode: `ADMIN_GRANT_BY_${adminEmail}`,
      grantedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function checkPaidAccess(userId: string, courseId: string): Promise<boolean> {
  try {
    const snap = await getDoc(doc(db, 'users', userId, 'paidAccess', courseId));
    return snap.exists();
  } catch {
    return false;
  }
}

// ===================================================================
// طلبات الاهتمام (Leads) لمسارات الدفع — تُخزَّن للأدمن فقط لحين تفعيل
// بوابة الدفع الفعلية، بدل أن تختفي محليًا كما كان سابقًا.
export async function saveCourseLead(lead: Omit<CourseLead, 'id' | 'createdAt' | 'status'>): Promise<void> {
  const id = `lead_${Date.now()}`;
  try {
    await setDoc(doc(db, 'leads', id), { ...lead, id, createdAt: new Date().toISOString(), status: 'new' });
  } catch (error) {
    console.warn('saveCourseLead:', error);
  }
}

export async function fetchLeads(): Promise<CourseLead[]> {
  try {
    const snap = await getDocs(collection(db, 'leads'));
    return snap.docs.map((d) => d.data() as CourseLead);
  } catch (error) {
    console.warn('fetchLeads:', error);
    return [];
  }
}
